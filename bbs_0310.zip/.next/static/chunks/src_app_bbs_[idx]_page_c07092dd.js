(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_bbs_[idx]_page_c07092dd.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_bbs_[idx]_page_c07092dd.js",
  "chunks": [
    "static/chunks/node_modules_a903ff61._.js",
    "static/chunks/src_app_1cbd6e34._.js",
    "static/chunks/src_app_page_module_d12eb71c.css"
  ],
  "source": "dynamic"
});
