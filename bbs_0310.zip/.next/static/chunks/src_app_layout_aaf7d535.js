(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_aaf7d535.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_aaf7d535.js",
  "chunks": [
    "static/chunks/[root of the server]__860c0698._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_6a276920._.js",
    "static/chunks/node_modules_next_dist_9a2d5fdb._.js"
  ],
  "source": "dynamic"
});
