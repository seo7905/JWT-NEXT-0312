(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_app_bbs_page_a5ded530.js", {

"[project]/src/app/bbs/page.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, d: __dirname, k: __turbopack_refresh__, m: module, e: exports } = __turbopack_context__;
{
const e = new Error(`Could not parse module '[project]/src/app/bbs/page.js'

Unexpected token `)`. Expected jsx identifier`);
e.code = 'MODULE_UNPARSEABLE';
throw e;}}),
}]);