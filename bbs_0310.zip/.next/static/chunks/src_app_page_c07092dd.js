(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_c07092dd.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_c07092dd.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_5eec24f3._.js",
    "static/chunks/src_app_page_module_d12eb71c.css"
  ],
  "source": "dynamic"
});
