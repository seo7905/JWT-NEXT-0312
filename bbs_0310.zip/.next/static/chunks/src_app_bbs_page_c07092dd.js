(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_bbs_page_c07092dd.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_bbs_page_c07092dd.js",
  "chunks": [
    "static/chunks/node_modules_67c34ef5._.js",
    "static/chunks/src_app_77ed7668._.js"
  ],
  "source": "dynamic"
});
