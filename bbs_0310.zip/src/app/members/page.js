
export default function Page(){
    return(
        <div>
            <h2>회원목록</h2>
            <hr/>
            
        </div>
    );
}